using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace DentalClinicManagementSystem
{
    public partial class ReportsForm : Form
    {
        public Action<string> NavigationRequested { get; set; }

        private PictureBox _sidebarLogo;
        private Button btnPatients;
        private Button btnAppointments;
        private Button btnDoctors;
        private Button btnTreatments;
        private Button btnReports;
        private Button btnLogout;

        public ReportsForm()
        {
            InitializeComponent();

            dgvMonthlySummary.Rows.Clear();
            dgvMonthlySummary.Rows.Add("September 2026", "980", "265", "14", "36,400 EGP");
            dgvMonthlySummary.Rows.Add("October 2026", "1,090", "290", "16", "41,200 EGP");
            dgvMonthlySummary.Rows.Add("November 2026", "1,250", "320", "18", "48,500 EGP");
        }

        private void RequestNavigation(string page)
        {
            Action<string> handler = NavigationRequested;
            if (handler != null)
            {
                handler(page);
                return;
            }

            if (page == "Dashboard" || page == "Logout")
            {
                this.Close();
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            ApplyUnifiedSidebar();
            ApplyPageLayout();
            Resize += (s, args) => ApplyPageLayout();
        }

        private void ApplyPageLayout()
        {
            if (pnlContent == null || pnlContent.ClientSize.Width < 480)
            {
                return;
            }

            pnlHeader.BackColor = Color.White;
            pnlHeader.Height = 112;

            lblPageTitle.AutoSize = true;
            lblPageTitle.Font = new Font("Segoe UI", 24F, FontStyle.Bold);
            lblPageTitle.ForeColor = Color.FromArgb(35, 75, 130);
            lblPageTitle.Location = new Point(40, 24);

            lblPageSubtitle.Font = new Font("Segoe UI", 10F, FontStyle.Regular);
            lblPageSubtitle.ForeColor = Color.FromArgb(120, 130, 145);
            lblPageSubtitle.Location = new Point(40, 82);

            int contentWidth = pnlContent.ClientSize.Width;
            int contentHeight = pnlContent.ClientSize.Height;
            int cardWidth = (contentWidth - 80 - 60) / 4;

            Panel[] cards = { pnlPatients, pnlAppointments, pnlTreatments, pnlRevenue };
            for (int i = 0; i < cards.Length; i++)
            {
                cards[i].SetBounds(40 + (i * (cardWidth + 20)), 40, cardWidth, 160);
            }

            pnlMonthlySummary.SetBounds(40, 224, contentWidth - 80, contentHeight - 264);
            dgvMonthlySummary.SetBounds(20, 86,
                pnlMonthlySummary.ClientSize.Width - 40,
                pnlMonthlySummary.ClientSize.Height - 106);
        }

        private void ApplyUnifiedSidebar()
        {
            pnlSidebar.Width = 240;
            pnlSidebar.BackColor = Color.FromArgb(35, 75, 130);
            lblBrand.Visible = false;
            lblBrandSub.Visible = false;

            if (_sidebarLogo == null)
            {
                _sidebarLogo = new PictureBox();
                _sidebarLogo.Name = "picSidebarLogo";
                _sidebarLogo.BackColor = Color.Transparent;
                _sidebarLogo.SizeMode = PictureBoxSizeMode.Zoom;
                _sidebarLogo.Image = (Image)new ComponentResourceManager(typeof(DashboardForm)).GetObject("pictlogo.Image");
                pnlSidebar.Controls.Add(_sidebarLogo);
            }
            _sidebarLogo.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            _sidebarLogo.SetBounds(20, 12, 120, 120);

            if (btnPatients == null)
            {
                btnPatients = CreateNavButton("btnPatients", "Patients", () => RequestNavigation("Patients"));
                btnAppointments = CreateNavButton("btnAppointments", "Appointments", () => RequestNavigation("Appointments"));
                btnDoctors = CreateNavButton("btnDoctors", "Doctors", () => RequestNavigation("Doctors"));
                btnTreatments = CreateNavButton("btnTreatments", "Treatments", () => RequestNavigation("Treatments"));
                btnReports = CreateNavButton("btnReports", "Reports", () => RequestNavigation("Reports"));
                btnLogout = CreateLogoutButton();
            }

            StyleNavButton(btnDashboard, "Dashboard", 0, false);
            StyleNavButton(btnPatients, "Patients", 1, false);
            StyleNavButton(btnAppointments, "Appointments", 2, false);
            StyleNavButton(btnDoctors, "Doctors", 3, false);
            StyleNavButton(btnTreatments, "Treatments", 4, false);
            StyleNavButton(btnReports, "Reports", 5, true);
            StyleLogoutButton(btnLogout);
        }

        private Button CreateNavButton(string name, string text, Action navigate)
        {
            Button button = new Button();
            button.Name = name;
            button.Text = text;
            button.Click += (s, e) => navigate();
            pnlSidebar.Controls.Add(button);
            return button;
        }

        private Button CreateLogoutButton()
        {
            Button button = new Button();
            button.Name = "btnLogout";
            button.Text = "Log Out";
            button.Click += (s, e) => RequestNavigation("Logout");
            pnlSidebar.Controls.Add(button);
            return button;
        }

        private void StyleNavButton(Button button, string text, int index, bool active)
        {
            button.Text = text;
            button.AutoSize = false;
            button.Dock = DockStyle.None;
            button.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            button.SetBounds(0, 144 + (index * 46), 240, 44);
            button.Margin = Padding.Empty;
            button.Padding = new Padding(24, 0, 0, 0);
            button.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            button.TextAlign = ContentAlignment.MiddleLeft;
            button.ForeColor = Color.White;
            button.BackColor = active ? Color.FromArgb(38, 95, 155) : Color.FromArgb(35, 75, 130);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.FlatAppearance.MouseOverBackColor = active ? Color.FromArgb(38, 95, 155) : Color.FromArgb(55, 105, 170);
            button.FlatAppearance.MouseDownBackColor = active ? Color.FromArgb(38, 95, 155) : Color.FromArgb(31, 78, 134);
            button.UseVisualStyleBackColor = false;
            button.Cursor = Cursors.Hand;
            button.Visible = true;
        }

        private void StyleLogoutButton(Button button)
        {
            button.Text = "Log Out";
            button.AutoSize = false;
            button.Dock = DockStyle.None;
            button.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            button.SetBounds(0, pnlSidebar.ClientSize.Height - 64, 240, 48);
            button.Margin = Padding.Empty;
            button.Padding = new Padding(24, 0, 0, 0);
            button.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            button.TextAlign = ContentAlignment.MiddleLeft;
            button.ForeColor = Color.White;
            button.BackColor = Color.FromArgb(35, 75, 130);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.FlatAppearance.MouseOverBackColor = Color.FromArgb(55, 105, 170);
            button.FlatAppearance.MouseDownBackColor = Color.FromArgb(31, 78, 134);
            button.UseVisualStyleBackColor = false;
            button.Cursor = Cursors.Hand;
            button.Visible = true;
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            RequestNavigation("Dashboard");
        }
    }
}
